function createBackButton(targetPage = "main.html") {
  const btnContainer = document.createElement("div");
  btnContainer.className = "back-button";

  const btn = document.createElement("button");
  btn.innerText = "← Back";
  btn.onclick = () => location.href = targetPage;

  btnContainer.appendChild(btn);
  document.body.appendChild(btnContainer);
}